// Captura o formulário de emissão de notas fiscais
document.getElementById('invoice-form').addEventListener('submit', function (e) {
    e.preventDefault(); // Previne o comportamento padrão do formulário

    // Captura os valores inseridos no formulário
    const clientName = document.getElementById('clientName').value;
    const product = document.getElementById('product').value;
    const quantity = parseInt(document.getElementById('quantity').value);
    const price = parseFloat(document.getElementById('price').value);

    // Calcula o valor total da nota fiscal
    const total = quantity * price;

    // Exibe os dados da nota fiscal gerada no frontend
    document.getElementById('client').innerText = clientName;
    document.getElementById('productDisplay').innerText = product;
    document.getElementById('quantityDisplay').innerText = quantity;
    document.getElementById('priceDisplay').innerText = price.toFixed(2);
    document.getElementById('totalDisplay').innerText = total.toFixed(2);

    // Exibe a seção com a nota fiscal gerada
    document.getElementById('invoice-display').classList.remove('hidden');

    // Prepara os dados para serem enviados ao servidor
    const invoiceData = {
        clientName: clientName,
        product: product,
        quantity: quantity,
        price: price
    };

    // Envia os dados para o servidor via POST para salvar a nota fiscal
    fetch('/save-invoice', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(invoiceData),
    })
    .then(response => response.text())
    .then(data => {
        console.log('Nota Fiscal Salva:', data);
    })
    .catch((error) => {
        console.error('Erro ao salvar a nota fiscal:', error);
    });
});

// Função para imprimir a nota fiscal gerada
document.getElementById('printInvoice').addEventListener('click', function () {
    window.print();
});